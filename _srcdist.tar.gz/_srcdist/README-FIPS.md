OpenSSL FIPS support
====================

This release does not support a FIPS 140-2 validated module.
